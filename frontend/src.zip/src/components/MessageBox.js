import React from "react";

const MessageBox = (props) => {
  return <div>{props.chiildren}</div>;
};

export default MessageBox;
