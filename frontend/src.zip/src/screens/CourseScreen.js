import React, { useEffect } from "react";
import data from "../data";
import { useDispatch, useSelector } from "react-redux";
import { useParams, Link } from "react-router-dom";
import LoadingBox from "../components/LoadingBox";
import MessageBox from "../components/MessageBox";

export default function CourseScreen(props) {
  const { id } = useParams();
  const courseId = id;
  const courseDetails = useSelector((state) => state.courseDetails);

  const course = data.courses.find((x) => x._id === id);
  if (!course) {
    return <div>Product not found</div>;
  }

  return (
    <div>
      <Link to="/">Back to result</Link>
      <div className="row top">
        <div className="col-2">
          <img src={course.image} alt={course.name} className="large" />
        </div>
        <div className="col-1">
          <ul>
            <li>
              <h1>{course.name}</h1>
            </li>
            <li>
              <h1>rating: {course.rating}</h1>
            </li>
            <li>price: ${course.price}</li>
            <li>
              Description:
              <p>{course.description}</p>
            </li>
          </ul>
        </div>
        <div className="col-1">
          <div className="card card-body">
            <ul>
              <li>
                <div className="row">
                  <div>Price</div>
                  <div className="price">Rs{course.price}</div>
                </div>
              </li>
              <li>
                <button className="primary block">Add to Cart </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
